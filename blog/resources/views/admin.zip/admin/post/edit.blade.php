@extends('layout.layout')
@section('title', 'Sửa bài viết mới')
@section('content')
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-3 col-md-6">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Thêm bài viết mới</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form role="form" action="{{ url('#') }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="txt-id">Tiêu đề bài viết</label>
                                    <input type="text" class="form-control" id="txt-title" name="title" placeholder="Vui lòng nhập tiêu để bài viết">
                                </div>
                                <div class="form-group">
                                    <label for="txt-description">Mô tả</label>
                                    <input type="text" class="form-control" id="txt-description" name="description" placeholder="Nhập mô tả bài viết">
                                </div>
                                <div class="form-group">
                                    <label for="txt-author">Tác giả</label>
                                    <input type="text" class="form-control" id="txt-author" name="author" placeholder="Nhập tên tác giả">
                                </div>
                                <div class="form-group">
                                    <label for="txt-category">Thể loại bài</label>
                                    <div class="controls">
                                        <select tabindex="1" name="category" data-placeholder="Chọn thể loại.." class="span8">
                                            <option value="">Chọn thể loại..</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="image">Ảnh đại diện bài viết</label>
                                    <div class="input-group">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="image" name="image">
                                            <label class="custom-file-label" for="image">Chọn ảnh</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="image">Nội dung bài viết</label>
                                    <div class="adjoined-bottom">
                                        <div class="grid-container">
                                            <div class="grid-width-100">
                                                <div id="editor">
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
@endsection
@section('script-section')
    <script src="{{ asset('plugins/bs-custom-file-input/bs-custom-file-input.min.js') }}"></script>

    <script src="{{ asset('editor/ckeditor/ckeditor.js') }}"></script>
    <script src="{{ asset('editor/ckeditor/js/sample.js') }}"></script>
    
    <script type="text/javascript">
        $(document).ready(function () {
            bsCustomFileInput.init();
        });
    </script>
    <script>
        initSample();
    </script>
    <script>
        CKEDITOR.replace('editor-vip',config);
    $('.img-bnupload').click(function(){
        $('.img-upload').click();
        //var a = $('input[type="file"]').val();
        //$(".img-bnupload").attr("src",a);
    });
    $('.img-upload').change( function(event) {
        var tmppath = URL.createObjectURL(event.target.files[0]);
            $(".img-bnupload").fadeIn("fast").attr('src',tmppath);       
        });
    </script>
@endsection
